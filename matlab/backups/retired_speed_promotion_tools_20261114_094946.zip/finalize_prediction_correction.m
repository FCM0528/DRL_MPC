function finalize_prediction_correction()
% Promote only after the measured closed-loop acceptance checks pass.
error('NominalSpeed:RetiredPromotion','旧降速工况的发布工具已停用。当前必须保持原70 km/h工况。');
root=setup_matlab_mpc();folder=fullfile(root,'results','prediction_correction');
v=load(fullfile(folder,'constrained_planned_raw.mat'),'out','metrics','p');p=v.p;out=v.out;
assert(v.metrics.qp_failures==0&&v.metrics.reached_range&&v.metrics.max_ay_excess_mps2<1e-6);
assert(p.correctionEnabled&&~p.observerEnabled&&p.safetyEnabled&&p.speedPlanActive);
m='DRL_MPC_MATLAB';open_system(fullfile(root,'models',[m '.slx']));assignin('base','matlab_mpc_parameters',p);
set_param(Simulink.ID.getFullName([m ':1']),'SIMFILE',fullfile(root,'carsim','coordinated_case','simfile.sim'));
set_param(m,'PostLoadFcn',sprintf('addpath(''%s''); setup_matlab_mpc;',root));
notes=find_system(m,'FindAll','on','Type','annotation');
for handle=notes'
    a=get_param(handle,'Object');
    if contains(a.Text,'Tustin'),a.Text='名义轨迹、物理松弛离散积分与一致线性化；原模型可显式回归';a.FontName='宋体';end
end
scope=Simulink.ID.getFullName([m ':106']);
for k=1:2
    mux=[scope '/Safety_Mux_' num2str(k)];neg=[scope '/Negative_Limit_' num2str(k)];
    if isempty(find_system(scope,'SearchDepth',1,'Name',['Negative_Limit_' num2str(k)]))
        set_param(mux,'Inputs','3');y=1060+(k-1)*150;
        add_block('simulink/Math Operations/Gain',neg,'Gain','-1','Position',[510 y+50 555 y+75],'FontName','宋体');
        fields=get_param([scope '/Safety_Fields'],'PortHandles');gain=get_param(neg,'PortHandles');dest=get_param(mux,'PortHandles');
        add_line(scope,fields.Outport(2*k),gain.Inport(1),'autorouting','on');add_line(scope,gain.Outport(1),dest.Inport(3),'autorouting','on');
    end
end
set_param(m,'SimulationCommand','update');save_system(m);
scopes=find_system(m,'LookUnderMasks','all','FollowLinks','off','BlockType','Scope');assert(numel(scopes)==10);
functions=find_system(m,'LookUnderMasks','all','FollowLinks','off','BlockType','S-Function');custom={};
for k=1:numel(functions),name=get_param(functions{k},'FunctionName');if ~strcmp(name,'sf_sfun'),custom{end+1}=name;end;end %#ok<AGROW>
assert(isequal(custom,{'vs_sf'}));
sources=dir(fullfile(root,'controllers','matlab','*.m'));messages=struct('file',{},'line',{},'message',{});
for file=sources'
    path=fullfile(file.folder,file.name);text=fileread(path);
    assert(~contains(text,{'mpc_paper_mex','mpc_mex(','coder.extrinsic','coder.ceval','loadlibrary(','calllib('}));
    info=checkcode(path,'-struct');for k=1:numel(info),messages(end+1)=struct('file',file.name,'line',info(k).line,'message',info(k).message);end %#ok<AGROW>
end
s=out.state_log.Data;mask=s(:,1)>=0&s(:,1)<=120;mu=p.gripGain*p.gripTable(1,2)+p.gripOffset;
front=abs(.5*(s(mask,13)+s(mask,14)));rear=abs(.5*(s(mask,15)+s(mask,16)));
assert(max(front)<=p.slipUtilization*mu*p.peakSlip(1)+1e-6);
assert(max(rear)<=p.slipUtilization*mu*p.peakSlip(2)+1e-6);
assert(max(abs(atan2(s(mask,4),s(mask,3))))<=p.betaLimit);
data=struct('passed',true,'model',m,'profile',3,'coordinated_case',true,'np',40,'nc',12,'scopes',numel(scopes), ...
    'external_sfunctions',{custom},'native_controller_files',numel(sources),'controller_mex_loaded',false, ...
    'max_front_slip_deg',max(front)*180/pi,'front_slip_limit_deg',p.slipUtilization*mu*p.peakSlip(1)*180/pi, ...
    'max_rear_slip_deg',max(rear)*180/pi,'rear_slip_limit_deg',p.slipUtilization*mu*p.peakSlip(2)*180/pi, ...
    'corrected_environment_training_episodes',0,'old_agent_applicability','legacy prediction model only', ...
    'additional_integral_observer_enabled',p.observerEnabled,'measured_force_residual_compensation_enabled',true, ...
    'real_time_qualified',false,'metrics',v.metrics,'observer_gain',p.observerGain,'disturbance_prediction_decay_s',p.disturbanceTime);
write('acceptance.json',data);write('source_review.json',struct('messages',{messages}));
print(['-s' Simulink.ID.getFullName([m ':76'])],'-dpng',fullfile(folder,'controller.png'));
print(['-s' scope],'-dpng',fullfile(folder,'scopes.png'));
fprintf('PREDICTION_CORRECTION_DELIVERY_PASS\n');
    function write(name,value),fid=fopen(fullfile(folder,name),'w','n','UTF-8');fprintf(fid,'%s\n',jsonencode(value,'PrettyPrint',true));fclose(fid);end
end

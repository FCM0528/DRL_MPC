function validate_correction_entry()
error('NominalSpeed:RetiredValidation','旧速度规划入口验证已停用；使用 nominal_speed_correction 中的当前验证结果。');
root=setup_matlab_mpc();folder=fullfile(root,'results','prediction_correction');
% Public default must reproduce the measured final constrained run.
out=run_corrected_preview();v=load(fullfile(folder,'constrained_planned_raw.mat'),'out');
difference=max(abs(out.state_log.Data-v.out.state_log.Data),[],'all');assert(difference<1e-6);
% Public legacy entry must still reproduce the historical 70 km/h baseline.
legacy=run_matlab_preview('fixed');v=load(fullfile(root,'results','matlab_comparison','matched_fixed_raw.mat'),'out');
legacyDifference=max(abs(legacy.state_log.Data-v.out.state_log.Data),[],'all');assert(legacyDifference<1e-6);
run_correction_experiments(5);plot_correction_results();
% Startup settings for a normal press of Simulink Run must be the corrected case.
setup_matlab_mpc();p=evalin('base','matlab_mpc_parameters');assert(p.correctionEnabled&&p.safetyEnabled&&~p.observerEnabled&&p.speedPlanActive);
m='DRL_MPC_MATLAB';assert(contains(get_param(Simulink.ID.getFullName([m ':1']),'SIMFILE'),'coordinated_case'));
data=struct('passed',true,'corrected_entry_state_max_difference',difference,'legacy_entry_state_max_difference',legacyDifference);
fid=fopen(fullfile(folder,'entry_validation.json'),'w');fprintf(fid,'%s\n',jsonencode(data,'PrettyPrint',true));fclose(fid);
fprintf('CORRECTION_PUBLIC_ENTRY_PASS\n');
end
